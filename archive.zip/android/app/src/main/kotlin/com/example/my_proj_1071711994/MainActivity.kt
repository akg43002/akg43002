package com.example.my_proj_1071711994

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
